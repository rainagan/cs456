Instructions of how to compile:
1. Change to the directory that contains Client.java, Server.java, client.sh, server.sh, and makefile
2. On the command line, type “make”, which will create a client.class and a server.class
3. Run server.sh by typing “./server.sh <req_code>”
4. Run client.sh by typing “./client.sh <server address> <n_port> <req_code> <msg>

Undergrad machines of test:
ubuntu1604-006

Version of make and compiler:
javac 1.8.0_144